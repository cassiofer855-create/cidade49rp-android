# CIDADE 49 RP — Projeto Godot 4

Protótipo de jogo de roleplay brasileiro para Android, atualmente offline e em desenvolvimento.

## Abrir o projeto

1. Instale Godot 4.3 ou superior.
2. Abra o Godot Project Manager e importe `project.godot`.
3. Execute com F6/F5.

## Conteúdo atual

- Menu principal e criação de personagem.
- Bairro 3D gerado por scripts, com comunidade, vielas, interiores simples e comércio.
- Controles de movimento por teclado e botões na tela.
- Veículos 3D de protótipo e viatura dirigível (sem NPC policial; a profissão policial foi pensada para jogadores online).
- Entregas, dinheiro e sistema policial básico offline.
- **Etapa 9:** três imóveis compráveis/vendáveis, Banco 49, caixa eletrônico, depósitos, saques e salvamento local de dinheiro, saldo bancário, propriedades e inventário.

## Testar a Etapa 9

- Aproxime-se de uma casa marcada `IMÓVEL`, use `INTERAGIR` e escolha comprar, entrar ou vender.
- Aproxime-se do caixa eletrônico do Banco 49 e use `INTERAGIR` para depositar ou sacar.
- O progresso econômico é salvo em `user://cidade49_save.cfg` no dispositivo.

## Exportar para Android

Configure os templates de exportação do Godot, Android SDK e JDK em seu ambiente. Depois crie um preset Android em Project > Export e gere um APK de teste.

## Estado e limitações

Este pacote é o projeto-fonte, não um APK. O Godot não estava disponível neste ambiente para executar e validar o projeto. Faça uma verificação no editor antes de compilar. O jogo ainda não possui servidor, multiplayer, persistência online ou proteção autoritativa de transações; os dados salvos nesta etapa são locais ao dispositivo.
