# Etapa 5 — Polícia

- Adicionado `PoliceSystem` como módulo separado.
- Adicionada delegacia, área restrita e marcadores de patrulha ao mapa.
- Adicionados botões de turno policial e regularização no HUD.
- Recompensas de patrulha integradas ao saldo existente.
- Adicionado estado de procurado, multa e temporizador de custódia.
