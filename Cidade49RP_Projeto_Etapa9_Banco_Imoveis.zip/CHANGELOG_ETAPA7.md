# Etapa 7 — Carros 3D e viatura policial

## Implementado
- Sedan civil 3D com carroceria, cabine, vidros, rodas, faróis e lanternas.
- Viatura policial 3D com pintura branca, faixa escura e barra de luz vermelha/azul estilizada.
- Viatura estacionada perto da delegacia; sedan próximo ao ponto inicial.
- Entrar e sair dos veículos pelo botão na tela ou pela tecla E.
- Direção arcade com aceleração, ré, esterçamento e câmera em terceira pessoa.
- Os controles direcionais existentes também controlam o veículo.
- A posição do jogador é ocultada e sua colisão desativada enquanto dirige.

## Decisão de design
Não foram criados NPCs policiais. A função policial será desempenhada por jogadores humanos quando o multiplayer for implementado. A viatura é apenas um veículo 3D disponível no protótipo offline.

## Limitações
- Modelos geométricos provisórios, sem modelos artísticos profissionais, animação física avançada, sirene sonora ou luzes piscantes funcionais.
- Não há multiplayer, servidor, sincronização ou permissões de função policial.
- Não foi possível executar o Godot neste ambiente; o projeto precisa ser aberto e testado no Godot 4.3+ antes de exportar.
- Nenhum APK foi compilado nesta etapa.
