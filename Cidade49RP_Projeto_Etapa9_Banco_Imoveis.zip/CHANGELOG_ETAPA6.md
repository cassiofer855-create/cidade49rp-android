# Etapa 6 — Primeiro mundo 3D

- A cena de jogo `World.tscn` foi migrada de Node2D para Node3D.
- Novo script `scripts/world_3d.gd` cria o cenário 3D, personagem, câmera e HUD.
- Mantidos o fluxo do menu e a criação/salvamento do personagem.
- Adicionados controles por toque e teclado, cenário de bairro/comunidade e pontos básicos de entrega/delegacia.
- Multiplayer e APK continuam pendentes.
- Não foi possível executar o Godot neste ambiente; validação em runtime pendente.
