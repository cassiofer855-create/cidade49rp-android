# CIDADE 49 RP — Etapa 9: economia, banco e propriedades

## Implementado no projeto-fonte

1. **Sistema de casas próprias:** três imóveis identificados no bairro, cada um com ID persistente e preço.
2. **Compra e venda:** compra desconta do dinheiro em mãos; venda devolve 70% do preço de tabela.
3. **Banco 49:** prédio e caixa eletrônico interativo no mapa.
4. **Depósitos:** transferência do dinheiro em mãos para o saldo bancário, com validação de valor e saldo.
5. **Saques:** transferência do saldo bancário para o dinheiro em mãos, com validação.
6. **Salvamento:** dinheiro, saldo bancário, imóveis e inventário são gravados em `user://cidade49_save.cfg` e carregados ao entrar no mundo.

## Como testar no Godot

1. Abra `project.godot` no Godot 4.3 ou superior.
2. Execute a cena principal e entre no mundo 3D.
3. Vá até uma casa marcada como `IMÓVEL`, pressione `INTERAGIR` e teste comprar, entrar e vender.
4. Vá até o `BANCO 49` e use o caixa eletrônico para depositar e sacar valores.
5. Feche o jogo pelo botão MENU e entre novamente para conferir se dinheiro, banco e imóveis continuam salvos.

## Limitações

- Valores e propriedades são locais ao dispositivo nesta versão offline; não há banco de dados ou autoridade de servidor.
- Multiplayer, sincronização entre jogadores, segurança contra alteração de saldo e transações online ainda precisam ser implementados no servidor.
- O projeto não foi executado no Godot neste ambiente e o APK não foi compilado; é necessário validar as cenas e scripts no editor antes de distribuir.
