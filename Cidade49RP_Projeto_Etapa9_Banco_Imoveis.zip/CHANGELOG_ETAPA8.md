# CIDADE 49 RP — Etapa 8: expansão do bairro

## Implementado no projeto-fonte
- Expansão cenográfica da comunidade com vielas, caminhos, escadarias, muretas e casas em patamares.
- Iluminação quente adicional nas vielas.
- Três casas com entrada interativa e interiores simples separados do mapa principal.
- Mercadinho 49 com menu de compras: água ($15) e lanche ($25), com saldo e inventário local.
- Garagem 49 com vagas marcadas; ao interagir enquanto dirige, o veículo é estacionado no pátio.
- Botão contextual INTERAGIR/SAIR DA CASA adaptado à interface touch já existente.
- Nenhum NPC policial ou civil foi adicionado. A função policial continua reservada a jogadores quando o multiplayer for implementado.

## Como testar
1. Abra `project.godot` no Godot 4.3 ou superior.
2. Execute o jogo, crie/seleciona um personagem e entre no mundo.
3. Explore o setor oeste/noroeste do bairro para encontrar as vielas e as casas com indicação ENTRAR.
4. Aproxime-se da porta e toque em INTERAGIR; dentro da casa, toque em SAIR DA CASA.
5. Visite o Mercadinho 49, perto da região da praça, e use INTERAGIR para comprar água ou lanche.
6. Leve um veículo até a Garagem 49, entre nele e interaja no pátio para estacioná-lo.

## Limitações conhecidas
- O cenário e os interiores são protótipos geométricos, sem modelos artísticos finais.
- Compras e inventário são locais e reiniciam ao fechar o jogo; não há persistência de inventário nem economia online.
- A garagem demonstra estacionamento simples; ainda não há propriedade de veículos, salvamento de garagem ou sistema de compra/venda.
- Não há multiplayer, servidor, NPCs ou APK compilado.
- O executável Godot não está disponível neste ambiente; o projeto não foi executado em tempo real. Validar no Godot antes de exportar APK.
