extends Node3D

# Protótipo 3D inicial: cenário gerado por código, personagem em terceira pessoa
# e controles de toque/teclado. Sistemas online ainda não fazem parte desta etapa.

var player: CharacterBody3D
var camera: Camera3D
var move_input := Vector2.ZERO
var touch_dirs := {"up": false, "down": false, "left": false, "right": false}
var player_name := "Morador"
var outfit := Color("#3d8fbd")
var money := 500
var hud_info: Label
var message_label: Label
var mission_active := false
var mission_stage := 0
var mission_marker: Vector3 = Vector3(0, 0, -24)
var mission_reward := 150
var wanted := false
var fine_due := 250
var in_restricted_area := false
var jail_timer := 0.0
var vehicles: Array[CharacterBody3D] = []
var current_vehicle: CharacterBody3D = null
var vehicle_button: Button
var _vehicle_action_was_down := false
var interaction_button: Button
var shop_popup: PopupPanel
var shop_status: Label
var inventory := {"Água": 0, "Lanche": 0}
var bank_balance := 0
var owned_properties: Array = []
var active_property: Dictionary = {}
var property_popup: PopupPanel
var property_status: Label
var bank_popup: PopupPanel
var bank_status: Label
var bank_amount_input: LineEdit
var interaction_points: Array[Dictionary] = []
var inside_house := false
var house_return_position := Vector3.ZERO

const WALK_SPEED := 5.5
const RUN_SPEED := 8.0
const GRAVITY := 18.0
const PICKUP_POINT := Vector3(-25, 0, -20)
const DROP_POINT := Vector3(27, 0, 24)
const STATION_POINT := Vector3(-29, 0, 24)
const RESTRICTED_CENTER := Vector3(28, 0, -25)

func _ready() -> void:
    _load_character()
    tree_exiting.connect(_save_game)
    _build_environment()
    _build_city()
    _build_neighborhood_expansion()
    _build_player()
    _build_vehicles()
    _build_hud()
    _build_interaction_ui()

func _load_character() -> void:
    var character_cfg := ConfigFile.new()
    if character_cfg.load("user://cidade49.cfg") == OK:
        player_name = str(character_cfg.get_value("personagem", "nome", "Morador"))
        var palette := [Color("#3d8fbd"), Color("#b85c45"), Color("#4b9b68"), Color("#9a72c4")]
        outfit = palette[int(character_cfg.get_value("personagem", "cor", 0)) % palette.size()]

    # Progresso econômico fica em arquivo separado do cadastro visual do personagem.
    var save_cfg := ConfigFile.new()
    if save_cfg.load("user://cidade49_save.cfg") == OK:
        money = int(save_cfg.get_value("economia", "dinheiro", money))
        bank_balance = int(save_cfg.get_value("economia", "banco", 0))
        var saved_owned = save_cfg.get_value("economia", "imoveis", [])
        for property_id in saved_owned:
            owned_properties.append(str(property_id))
        inventory["Água"] = int(save_cfg.get_value("inventario", "agua", 0))
        inventory["Lanche"] = int(save_cfg.get_value("inventario", "lanche", 0))

func _save_game() -> void:
    var cfg := ConfigFile.new()
    cfg.set_value("personagem", "nome", player_name)
    cfg.set_value("economia", "dinheiro", money)
    cfg.set_value("economia", "banco", bank_balance)
    cfg.set_value("economia", "imoveis", owned_properties)
    cfg.set_value("inventario", "agua", inventory.get("Água", 0))
    cfg.set_value("inventario", "lanche", inventory.get("Lanche", 0))
    var err := cfg.save("user://cidade49_save.cfg")
    if err != OK:
        push_warning("Não foi possível salvar o progresso: %s" % error_string(err))

func _material(color: Color, roughness := 0.9) -> StandardMaterial3D:
    var mat := StandardMaterial3D.new()
    mat.albedo_color = color
    mat.roughness = roughness
    return mat

func _build_environment() -> void:
    var world_env := WorldEnvironment.new()
    var env := Environment.new()
    env.background_mode = Environment.BG_SKY
    var sky := Sky.new()
    var sky_mat := ProceduralSkyMaterial.new()
    sky_mat.sky_top_color = Color("#203a59")
    sky_mat.sky_horizon_color = Color("#e0a878")
    sky_mat.ground_bottom_color = Color("#17232d")
    sky_mat.ground_horizon_color = Color("#b17e63")
    sky.sky_material = sky_mat
    env.sky = sky
    env.ambient_light_source = Environment.AMBIENT_SOURCE_COLOR
    env.ambient_light_color = Color("#a8b7ca")
    env.ambient_light_energy = 0.55
    env.tonemap_mode = Environment.TONE_MAPPER_FILMIC
    world_env.environment = env
    add_child(world_env)

    var sun := DirectionalLight3D.new()
    sun.rotation_degrees = Vector3(-48, -28, 0)
    sun.light_energy = 1.25
    sun.shadow_enabled = true
    add_child(sun)

func _add_box(parent: Node3D, pos: Vector3, size: Vector3, color: Color, collision := true) -> MeshInstance3D:
    var body: Node3D = StaticBody3D.new() if collision else Node3D.new()
    body.position = pos
    parent.add_child(body)
    var mesh_instance := MeshInstance3D.new()
    var box := BoxMesh.new()
    box.size = size
    mesh_instance.mesh = box
    mesh_instance.material_override = _material(color)
    body.add_child(mesh_instance)
    if collision:
        var shape_node := CollisionShape3D.new()
        var shape := BoxShape3D.new()
        shape.size = size
        shape_node.shape = shape
        body.add_child(shape_node)
    return mesh_instance

func _build_city() -> void:
    # Terreno e malha de ruas
    _add_box(self, Vector3(0, -0.55, 0), Vector3(100, 1, 100), Color("#58734f"))
    _add_box(self, Vector3(0, -0.02, 0), Vector3(12, 0.12, 100), Color("#343b43"), false)
    _add_box(self, Vector3(0, 0.0, 0), Vector3(100, 0.12, 12), Color("#343b43"), false)
    for z in range(-44, 48, 8):
        _add_box(self, Vector3(0, 0.08, float(z)), Vector3(0.18, 0.025, 3.5), Color("#e8d9a6"), false)
    for x in range(-44, 48, 8):
        _add_box(self, Vector3(float(x), 0.08, 0), Vector3(3.5, 0.025, 0.18), Color("#e8d9a6"), false)

    # Quadras residenciais com fachadas, portas e janelas
    var house_colors := [Color("#c18a66"), Color("#d0b47e"), Color("#9c7770"), Color("#b6a080"), Color("#7e9b91")]
    for i in range(5):
        var x := -42.0 + float(i) * 20.0
        _make_house(Vector3(x, 0, -22), house_colors[i % house_colors.size()], Vector3(8, 5, 7))
        _make_house(Vector3(x, 0, 22), house_colors[(i + 2) % house_colors.size()], Vector3(8, 5, 7))
        var z := -42.0 + float(i) * 20.0
        _make_house(Vector3(-22, 0, z), house_colors[(i + 1) % house_colors.size()], Vector3(7, 5, 8))
        _make_house(Vector3(22, 0, z), house_colors[(i + 3) % house_colors.size()], Vector3(7, 5, 8))

    # Morro e casas da comunidade em níveis escalonados
    var hill := MeshInstance3D.new()
    var hill_mesh := SphereMesh.new()
    hill_mesh.radius = 1.0
    hill_mesh.height = 2.0
    hill.mesh = hill_mesh
    hill.scale = Vector3(27, 9, 19)
    hill.position = Vector3(0, 5.5, -43)
    hill.material_override = _material(Color("#425e43"))
    add_child(hill)
    for row in range(3):
        for col in range(6):
            var hx := -20.0 + float(col) * 8.0
            var hz := -48.0 - float(row) * 5.0
            var hy := 1.0 + float(row) * 2.2
            _make_house(Vector3(hx, hy, hz), house_colors[(row + col) % house_colors.size()], Vector3(5.5, 3.5, 4.5))

    # Delegacia, garagem e área comunitária
    _make_landmark(STATION_POINT, "DELEGACIA", Color("#647f99"))
    _make_landmark(Vector3(36, 0, -36), "BANCO 49", Color("#668b83"))
    _add_box(self, Vector3(36, 1.0, -29.5), Vector3(0.75, 1.8, 0.45), Color("#263c45"))
    _add_box(self, Vector3(36, 1.1, -29.22), Vector3(0.5, 0.65, 0.08), Color("#8bc6c7"), false)
    _add_label_3d("CAIXA ELETRÔNICO", Vector3(36, 2.5, -29.5), Color("#c8f2e8"))
    interaction_points.append({"type": "atm", "pos": Vector3(36, 0, -28.0), "name": "Caixa eletrônico 49"})
    _make_landmark(Vector3(30, 0, 30), "GARAGEM", Color("#bd9455"))
    _make_landmark(Vector3(0, 0, 36), "PRAÇA 49", Color("#72956a"))
    _add_box(self, RESTRICTED_CENTER + Vector3(0, 0.06, 0), Vector3(12, 0.08, 12), Color(0.75, 0.22, 0.16, 0.45), false)
    _add_label_3d("ÁREA RESTRITA", RESTRICTED_CENTER + Vector3(0, 2.8, 0), Color("#ffb09b"))
    _add_waypoint(PICKUP_POINT, Color("#f2bd65"), "RETIRADA")
    _add_waypoint(DROP_POINT, Color("#6fe0a1"), "DESTINO")

    # Postes simples iluminando as ruas
    for x in [-18.0, 18.0]:
        for z in [-35.0, -12.0, 12.0, 35.0]:
            _add_box(self, Vector3(x, 2.2, z), Vector3(0.16, 4.4, 0.16), Color("#303943"))
            var lamp := OmniLight3D.new()
            lamp.position = Vector3(x, 4.3, z)
            lamp.light_color = Color("#ffd69a")
            lamp.light_energy = 0.8
            lamp.omni_range = 8.0
            add_child(lamp)

func _make_house(pos: Vector3, color: Color, size: Vector3) -> void:
    _add_box(self, pos + Vector3(0, size.y * 0.5, 0), size, color)
    _add_box(self, pos + Vector3(0, size.y + 0.18, 0), Vector3(size.x * 1.08, 0.35, size.z * 1.08), Color("#41464b"), false)
    _add_box(self, pos + Vector3(0, 1.2, size.z * 0.5 + 0.06), Vector3(1.15, 2.4, 0.12), Color("#49372d"), false)
    for side in [-1.0, 1.0]:
        _add_box(self, pos + Vector3(side * size.x * 0.25, 2.5, size.z * 0.5 + 0.07), Vector3(1.0, 0.9, 0.13), Color("#9ac3cf"), false)

func _make_landmark(pos: Vector3, title: String, color: Color) -> void:
    _add_box(self, pos + Vector3(0, 1.6, 0), Vector3(9, 3.2, 7), color)
    _add_box(self, pos + Vector3(0, 3.35, 0), Vector3(9.6, 0.3, 7.6), Color("#303943"), false)
    _add_label_3d(title, pos + Vector3(0, 4.4, 0), Color.WHITE)

func _add_label_3d(text_value: String, pos: Vector3, color: Color) -> void:
    var label := Label3D.new()
    label.text = text_value
    label.position = pos
    label.billboard = BaseMaterial3D.BILLBOARD_ENABLED
    label.font_size = 48
    label.modulate = color
    add_child(label)

func _add_waypoint(pos: Vector3, color: Color, caption: String) -> void:
    var marker := MeshInstance3D.new()
    var sphere := SphereMesh.new()
    sphere.radius = 0.65
    sphere.height = 1.3
    marker.mesh = sphere
    marker.position = pos + Vector3(0, 0.9, 0)
    marker.material_override = _material(color, 0.35)
    add_child(marker)
    _add_label_3d(caption, pos + Vector3(0, 2.0, 0), color)


func _build_neighborhood_expansion() -> void:
    # Expansão da comunidade: vielas estreitas, escadarias e casas em patamares.
    # A área é cenográfica e não inclui NPCs; os serviços policiais ficam para jogadores online.
    _add_box(self, Vector3(-37, 0.0, -19), Vector3(27, 0.12, 34), Color("#756b5d"), false)
    var alley_color := Color("#55575a")
    for z in [-31.0, -22.0, -13.0, -4.0]:
        _add_box(self, Vector3(-37, 0.08, z), Vector3(2.1, 0.12, 8.6), alley_color, false)
    for x in [-46.0, -37.0, -28.0]:
        _add_box(self, Vector3(x, 0.08, -18.0), Vector3(8.5, 0.12, 1.8), alley_color, false)

    var favela_colors := [Color("#bd8865"), Color("#d1b879"), Color("#8f9c91"), Color("#b47770"), Color("#7895a5")]
    for row in range(3):
        for col in range(3):
            var hx := -46.0 + float(col) * 8.5
            var hz := -33.0 + float(row) * 10.0
            var level := float((row + col) % 2) * 1.15
            _make_house(Vector3(hx, level, hz), favela_colors[(row * 2 + col) % favela_colors.size()], Vector3(5.2, 3.3, 5.0))
            # Escadarias laterais entre os níveis do morro.
            if col == 1:
                _add_box(self, Vector3(hx + 3.4, level + 0.35, hz + 2.5), Vector3(1.4, 0.18, 4.2), Color("#99918a"), false)

    # Muretas, postes e iluminação quente nas vielas.
    for z in [-28.0, -10.0]:
        _add_box(self, Vector3(-25.0, 0.55, z), Vector3(0.35, 1.1, 14.0), Color("#68635c"))
    for pos in [Vector3(-46, 2.4, -28), Vector3(-29, 2.4, -9), Vector3(-38, 2.4, 1)]:
        _add_box(self, pos + Vector3(0, -1.2, 0), Vector3(0.14, 2.4, 0.14), Color("#303943"))
        var lamp := OmniLight3D.new()
        lamp.position = pos
        lamp.light_color = Color("#ffd19a")
        lamp.light_energy = 0.7
        lamp.omni_range = 7.5
        add_child(lamp)

    # Três casas acessíveis: interação na porta leva a um interior simples.
    _register_house(Vector3(-46.0, 0.0, -29.8), Vector3(125, 0, 0), "CASA DA VIELA", "casa_viela", 2500)
    _register_house(Vector3(-37.5, 1.15, -19.8), Vector3(145, 0, 0), "CASA DO MORRO", "casa_morro", 3500)
    _register_house(Vector3(-29.0, 0.0, -9.8), Vector3(165, 0, 0), "CASA DA ESCADARIA", "casa_escadaria", 5000)

    # Comércio de bairro com fachada, toldo e balcão.
    _add_box(self, Vector3(-32, 1.7, 31), Vector3(8.5, 3.4, 6.5), Color("#c58d5c"))
    _add_box(self, Vector3(-32, 3.55, 31), Vector3(9.0, 0.28, 7.0), Color("#38434b"), false)
    _add_box(self, Vector3(-32, 1.45, 27.68), Vector3(3.5, 1.35, 0.12), Color("#a9d0d8"), false)
    _add_box(self, Vector3(-32, 0.65, 27.45), Vector3(4.0, 0.8, 0.7), Color("#604b39"), false)
    _add_label_3d("MERCADINHO 49", Vector3(-32, 4.7, 31), Color("#ffe2a8"))
    interaction_points.append({"type": "shop", "pos": Vector3(-32, 0, 26.0), "name": "Mercadinho 49"})

    # Pátio de garagem com vagas marcadas e ponto de interação.
    _add_box(self, Vector3(31, 0.08, 39), Vector3(16, 0.12, 12), Color("#555b60"), false)
    for x in [25.5, 31.0, 36.5]:
        _add_box(self, Vector3(x, 0.16, 39), Vector3(0.12, 0.025, 8.5), Color("#f1d58b"), false)
    _add_label_3d("GARAGEM 49", Vector3(31, 2.4, 33), Color("#ffe0a0"))
    interaction_points.append({"type": "garage", "pos": Vector3(31, 0, 32), "name": "Garagem 49"})

func _register_house(door_position: Vector3, interior_origin: Vector3, house_name: String, property_id: String, price: int) -> void:
    _add_label_3d("IMÓVEL • $%d" % price, door_position + Vector3(0, 2.6, 0.4), Color("#f5d18a"))
    interaction_points.append({"type": "property", "id": property_id, "price": price, "pos": door_position, "interior": interior_origin, "name": house_name})
    _build_house_interior(interior_origin, house_name)

func _build_house_interior(origin: Vector3, house_name: String) -> void:
    # Interior simples construído fora do mapa principal; o jogador é transportado até ele.
    _add_box(self, origin + Vector3(0, -0.2, 0), Vector3(8, 0.4, 8), Color("#9b8b78"))
    _add_box(self, origin + Vector3(0, 1.5, -4), Vector3(8, 3, 0.25), Color("#d5c4a8"))
    _add_box(self, origin + Vector3(-4, 1.5, 0), Vector3(0.25, 3, 8), Color("#c9b89e"))
    _add_box(self, origin + Vector3(4, 1.5, 0), Vector3(0.25, 3, 8), Color("#c9b89e"))
    _add_box(self, origin + Vector3(0, 3.0, 0), Vector3(8, 0.25, 8), Color("#554b43"))
    _add_box(self, origin + Vector3(-1.4, 0.45, -1.0), Vector3(2.4, 0.65, 1.5), Color("#72513e"), false)
    _add_box(self, origin + Vector3(1.8, 0.42, 1.6), Vector3(1.4, 0.55, 1.2), Color("#48616a"), false)
    _add_label_3d(house_name, origin + Vector3(0, 2.2, -3.7), Color("#fff0cf"))

func _build_interaction_ui() -> void:
    var layer := get_node_or_null("CanvasLayer")
    if layer == null:
        # O HUD principal cria seu CanvasLayer como primeiro filho de interface.
        for child in get_children():
            if child is CanvasLayer:
                layer = child
                break
    if layer == null:
        return
    interaction_button = Button.new()
    interaction_button.text = "INTERAGIR"
    interaction_button.position = Vector2(770, 616)
    interaction_button.custom_minimum_size = Vector2(190, 52)
    interaction_button.pressed.connect(_interact_nearby)
    layer.add_child(interaction_button)

    shop_popup = PopupPanel.new()
    var panel_box := VBoxContainer.new()
    panel_box.custom_minimum_size = Vector2(300, 220)
    panel_box.add_theme_constant_override("separation", 10)
    shop_popup.add_child(panel_box)
    var shop_title := Label.new()
    shop_title.text = "MERCADINHO 49"
    shop_title.add_theme_font_size_override("font_size", 20)
    panel_box.add_child(shop_title)
    shop_status = Label.new()
    shop_status.text = "Compre itens para seu personagem."
    panel_box.add_child(shop_status)
    var water_btn := Button.new()
    water_btn.text = "Comprar água — $15"
    water_btn.pressed.connect(func(): _buy_shop_item("Água", 15))
    panel_box.add_child(water_btn)
    var snack_btn := Button.new()
    snack_btn.text = "Comprar lanche — $25"
    snack_btn.pressed.connect(func(): _buy_shop_item("Lanche", 25))
    panel_box.add_child(snack_btn)
    var close_btn := Button.new()
    close_btn.text = "FECHAR"
    close_btn.pressed.connect(func(): shop_popup.hide())
    panel_box.add_child(close_btn)
    add_child(shop_popup)

    _build_property_popup()
    _build_bank_popup()

func _build_property_popup() -> void:
    property_popup = PopupPanel.new()
    var box := VBoxContainer.new()
    box.custom_minimum_size = Vector2(330, 250)
    box.add_theme_constant_override("separation", 9)
    property_popup.add_child(box)
    var title := Label.new()
    title.text = "IMÓVEIS CIDADE 49"
    title.add_theme_font_size_override("font_size", 19)
    box.add_child(title)
    property_status = Label.new()
    property_status.autowrap_mode = TextServer.AUTOWRAP_WORD_SMART
    box.add_child(property_status)
    var buy_btn := Button.new()
    buy_btn.text = "COMPRAR IMÓVEL"
    buy_btn.pressed.connect(_buy_active_property)
    box.add_child(buy_btn)
    var enter_btn := Button.new()
    enter_btn.text = "ENTRAR NA MINHA CASA"
    enter_btn.pressed.connect(_enter_active_property)
    box.add_child(enter_btn)
    var sell_btn := Button.new()
    sell_btn.text = "VENDER IMÓVEL (70%)"
    sell_btn.pressed.connect(_sell_active_property)
    box.add_child(sell_btn)
    var close_btn := Button.new()
    close_btn.text = "FECHAR"
    close_btn.pressed.connect(func(): property_popup.hide())
    box.add_child(close_btn)
    add_child(property_popup)

func _build_bank_popup() -> void:
    bank_popup = PopupPanel.new()
    var box := VBoxContainer.new()
    box.custom_minimum_size = Vector2(330, 230)
    box.add_theme_constant_override("separation", 9)
    bank_popup.add_child(box)
    var title := Label.new()
    title.text = "BANCO 49 — CAIXA ELETRÔNICO"
    title.add_theme_font_size_override("font_size", 18)
    box.add_child(title)
    bank_status = Label.new()
    box.add_child(bank_status)
    bank_amount_input = LineEdit.new()
    bank_amount_input.placeholder_text = "Valor em $ (ex.: 100)"
    bank_amount_input.text = "100"
    bank_amount_input.virtual_keyboard_type = LineEdit.KEYBOARD_TYPE_NUMBER
    box.add_child(bank_amount_input)
    var deposit_btn := Button.new()
    deposit_btn.text = "DEPOSITAR"
    deposit_btn.pressed.connect(_deposit_money)
    box.add_child(deposit_btn)
    var withdraw_btn := Button.new()
    withdraw_btn.text = "SACAR"
    withdraw_btn.pressed.connect(_withdraw_money)
    box.add_child(withdraw_btn)
    var close_btn := Button.new()
    close_btn.text = "FECHAR"
    close_btn.pressed.connect(func(): bank_popup.hide())
    box.add_child(close_btn)
    add_child(bank_popup)

func _nearest_interaction() -> Dictionary:
    var actor_position := current_vehicle.global_position if current_vehicle != null else player.global_position
    if inside_house:
        return {"type": "exit", "pos": actor_position, "name": "Sair da casa"}
    var best: Dictionary = {}
    var best_distance := 4.2
    for point in interaction_points:
        var p: Vector3 = point["pos"]
        var distance := Vector2(actor_position.x - p.x, actor_position.z - p.z).length()
        if distance < best_distance:
            best_distance = distance
            best = point
    return best

func _interact_nearby() -> void:
    var point := _nearest_interaction()
    if point.is_empty():
        _show_message("Aproxime-se de uma casa, loja ou garagem.")
        return
    match str(point["type"]):
        "property":
            if current_vehicle != null:
                _show_message("Saia do veículo para acessar o imóvel.")
                return
            active_property = point
            var property_id := str(point["id"])
            var is_owned := owned_properties.has(property_id)
            property_status.text = "%s\nPreço: $%d\n%s\nDinheiro: $%d" % [point["name"], int(point["price"]), "IMÓVEL SEU" if is_owned else "Disponível para compra", money]
            property_popup.popup_centered()
        "atm":
            bank_status.text = "Dinheiro: $%d\nSaldo bancário: $%d" % [money, bank_balance]
            bank_amount_input.text = "100"
            bank_popup.popup_centered()
        "exit":
            inside_house = false
            player.global_position = house_return_position + Vector3(0, 0.2, 1.8)
            _show_message("Você saiu de casa.")
        "shop":
            shop_status.text = "Água: %d  |  Lanches: %d" % [inventory["Água"], inventory["Lanche"]]
            shop_popup.popup_centered()
        "garage":
            _garage_action()

func _buy_shop_item(item_name: String, price: int) -> void:
    if money < price:
        shop_status.text = "Dinheiro insuficiente. Saldo: $%d" % money
        return
    money -= price
    inventory[item_name] += 1
    shop_status.text = "%s comprado! Quantidade: %d" % [item_name, inventory[item_name]]
    _save_game()
    _refresh_hud()

func _buy_active_property() -> void:
    if active_property.is_empty():
        return
    var property_id := str(active_property["id"])
    var price := int(active_property["price"])
    if owned_properties.has(property_id):
        property_status.text = "Você já é proprietário deste imóvel."
        return
    if money < price:
        property_status.text = "Saldo insuficiente. Faltam $%d." % (price - money)
        return
    money -= price
    owned_properties.append(property_id)
    _save_game()
    property_status.text = "Compra realizada! %s agora é seu." % active_property["name"]
    _refresh_hud()

func _enter_active_property() -> void:
    if active_property.is_empty():
        return
    var property_id := str(active_property["id"])
    if not owned_properties.has(property_id):
        property_status.text = "Você precisa comprar este imóvel antes de entrar."
        return
    property_popup.hide()
    house_return_position = player.global_position
    inside_house = true
    player.global_position = active_property["interior"] + Vector3(0, 1.0, 2.2)
    _show_message("Você entrou em %s. Use INTERAGIR para sair." % active_property["name"])

func _sell_active_property() -> void:
    if active_property.is_empty():
        return
    var property_id := str(active_property["id"])
    if not owned_properties.has(property_id):
        property_status.text = "Você não possui este imóvel."
        return
    var refund := int(float(active_property["price"]) * 0.70)
    owned_properties.erase(property_id)
    money += refund
    _save_game()
    property_status.text = "Imóvel vendido por $%d." % refund
    _refresh_hud()

func _deposit_money() -> void:
    var amount := bank_amount_input.text.to_int()
    if amount <= 0:
        bank_status.text = "Digite um valor válido."
        return
    if amount > money:
        bank_status.text = "Dinheiro em mãos insuficiente."
        return
    money -= amount
    bank_balance += amount
    _save_game()
    bank_status.text = "Depósito de $%d realizado.\nDinheiro: $%d | Banco: $%d" % [amount, money, bank_balance]
    _refresh_hud()

func _withdraw_money() -> void:
    var amount := bank_amount_input.text.to_int()
    if amount <= 0:
        bank_status.text = "Digite um valor válido."
        return
    if amount > bank_balance:
        bank_status.text = "Saldo bancário insuficiente."
        return
    bank_balance -= amount
    money += amount
    _save_game()
    bank_status.text = "Saque de $%d realizado.\nDinheiro: $%d | Banco: $%d" % [amount, money, bank_balance]
    _refresh_hud()

func _garage_action() -> void:
    if current_vehicle != null:
        current_vehicle.global_position = Vector3(31, 0.2, 39)
        current_vehicle.velocity = Vector3.ZERO
        player.global_position = Vector3(31, 1.0, 34)
        player.visible = true
        player.get_node("CollisionShape3D").set_deferred("disabled", false)
        current_vehicle = null
        vehicle_button.text = "ENTRAR NO VEÍCULO"
        _show_message("Veículo estacionado na Garagem 49.")
    else:
        _show_message("Garagem 49: aproxime-se de um veículo e entre nele para estacionar.")


func _build_player() -> void:
    player = CharacterBody3D.new()
    player.position = Vector3(0, 1.1, 8)
    player.floor_snap_length = 0.35
    add_child(player)

    var collision := CollisionShape3D.new()
    var capsule := CapsuleShape3D.new()
    capsule.radius = 0.42
    capsule.height = 1.8
    collision.shape = capsule
    player.add_child(collision)

    var torso := MeshInstance3D.new()
    var torso_mesh := CapsuleMesh.new()
    torso_mesh.radius = 0.43
    torso_mesh.height = 1.15
    torso.mesh = torso_mesh
    torso.position = Vector3(0, 0.0, 0)
    torso.material_override = _material(outfit)
    player.add_child(torso)

    var head := MeshInstance3D.new()
    var head_mesh := SphereMesh.new()
    head_mesh.radius = 0.28
    head_mesh.height = 0.56
    head.mesh = head_mesh
    head.position = Vector3(0, 0.82, 0)
    head.material_override = _material(Color("#bd8c69"))
    player.add_child(head)

    var camera_pivot := Node3D.new()
    camera_pivot.position = Vector3(0, 1.0, 0)
    player.add_child(camera_pivot)
    camera = Camera3D.new()
    camera.position = Vector3(0, 4.2, 7.8)
    camera.current = true
    camera.fov = 72.0
    camera_pivot.add_child(camera)
    camera.look_at(player.global_position + Vector3(0, 1.2, 0), Vector3.UP)


func _build_vehicles() -> void:
    # Um carro civil e uma viatura ficam disponíveis no mapa. Não há NPCs policiais:
    # a função policial será exercida por jogadores quando o multiplayer existir.
    var civilian := _make_vehicle(Vector3(3.5, 0.0, 8.0), "SEDAN 49", false)
    civilian.set_meta("max_speed", 16.0)
    var patrol := _make_vehicle(STATION_POINT + Vector3(0, 0.0, -7.0), "VIATURA 49", true)
    patrol.set_meta("max_speed", 18.0)

func _make_vehicle(pos: Vector3, vehicle_name: String, is_police: bool) -> CharacterBody3D:
    var vehicle := CharacterBody3D.new()
    vehicle.name = vehicle_name.replace(" ", "_")
    vehicle.position = pos
    vehicle.floor_snap_length = 0.25
    vehicle.set_meta("vehicle_name", vehicle_name)
    vehicle.set_meta("is_police", is_police)
    add_child(vehicle)

    var collision := CollisionShape3D.new()
    var shape := BoxShape3D.new()
    shape.size = Vector3(2.0, 1.0, 4.2)
    collision.shape = shape
    collision.position.y = 0.54
    vehicle.add_child(collision)

    var body_color := Color("#e7e9ed") if is_police else Color("#2876a8")
    _vehicle_box(vehicle, Vector3(0, 0.72, 0), Vector3(2.0, 0.55, 4.2), body_color)
    _vehicle_box(vehicle, Vector3(0, 1.22, -0.12), Vector3(1.65, 0.72, 2.15), Color("#263746"))
    _vehicle_box(vehicle, Vector3(0, 1.62, -0.12), Vector3(1.55, 0.08, 2.0), Color("#17232d"))
    _vehicle_box(vehicle, Vector3(0, 0.52, -2.12), Vector3(1.9, 0.18, 0.12), Color("#b9c2cb"))
    _vehicle_box(vehicle, Vector3(0, 0.52, 2.12), Vector3(1.9, 0.18, 0.12), Color("#b9c2cb"))
    # Para-brisa dianteiro e traseiro estilizados.
    _vehicle_box(vehicle, Vector3(0, 1.28, -1.22), Vector3(1.48, 0.48, 0.08), Color("#83b6ca"))
    _vehicle_box(vehicle, Vector3(0, 1.28, 0.98), Vector3(1.48, 0.48, 0.08), Color("#83b6ca"))

    for side in [-1.0, 1.0]:
        for z in [-1.35, 1.35]:
            var wheel := MeshInstance3D.new()
            var wheel_mesh := CylinderMesh.new()
            wheel_mesh.top_radius = 0.43
            wheel_mesh.bottom_radius = 0.43
            wheel_mesh.height = 0.24
            wheel.mesh = wheel_mesh
            wheel.rotation.z = PI / 2.0
            wheel.position = Vector3(side * 1.02, 0.48, z)
            wheel.material_override = _material(Color("#17191d"))
            vehicle.add_child(wheel)
            var hub := MeshInstance3D.new()
            var hub_mesh := CylinderMesh.new()
            hub_mesh.top_radius = 0.19
            hub_mesh.bottom_radius = 0.19
            hub_mesh.height = 0.255
            hub.mesh = hub_mesh
            hub.rotation.z = PI / 2.0
            hub.position = Vector3(side * 1.03, 0.48, z)
            hub.material_override = _material(Color("#aeb7c0"))
            vehicle.add_child(hub)

    for side in [-1.0, 1.0]:
        _vehicle_box(vehicle, Vector3(side * 0.68, 0.78, -2.13), Vector3(0.42, 0.2, 0.06), Color("#fff1b5"))
        _vehicle_box(vehicle, Vector3(side * 0.68, 0.78, 2.13), Vector3(0.42, 0.2, 0.06), Color("#b53c37"))

    if is_police:
        _vehicle_box(vehicle, Vector3(0, 1.68, -0.05), Vector3(0.95, 0.16, 0.32), Color("#20252b"))
        _vehicle_box(vehicle, Vector3(-0.28, 1.79, -0.05), Vector3(0.35, 0.12, 0.28), Color("#d94b45"))
        _vehicle_box(vehicle, Vector3(0.28, 1.79, -0.05), Vector3(0.35, 0.12, 0.28), Color("#397bd6"))
        _vehicle_box(vehicle, Vector3(0, 0.98, 0.0), Vector3(2.02, 0.12, 2.3), Color("#1f2933"))
        _vehicle_label(vehicle, "VIATURA 49", Vector3(0, 2.6, 0), Color("#dcecff"))
    else:
        _vehicle_label(vehicle, "SEDAN 49", Vector3(0, 2.3, 0), Color("#e7f2ff"))

    vehicles.append(vehicle)
    return vehicle

func _vehicle_label(parent: Node3D, caption: String, local_pos: Vector3, color: Color) -> void:
    var label := Label3D.new()
    label.text = caption
    label.position = local_pos
    label.billboard = BaseMaterial3D.BILLBOARD_ENABLED
    label.font_size = 34
    label.modulate = color
    parent.add_child(label)

func _vehicle_box(parent: Node3D, pos: Vector3, size: Vector3, color: Color) -> void:
    var mesh_instance := MeshInstance3D.new()
    var mesh := BoxMesh.new()
    mesh.size = size
    mesh_instance.mesh = mesh
    mesh_instance.position = pos
    mesh_instance.material_override = _material(color, 0.55)
    parent.add_child(mesh_instance)

func _nearest_vehicle() -> CharacterBody3D:
    var nearest: CharacterBody3D = null
    var nearest_distance := 4.5
    for vehicle in vehicles:
        if not is_instance_valid(vehicle):
            continue
        var distance := player.global_position.distance_to(vehicle.global_position)
        if distance < nearest_distance:
            nearest_distance = distance
            nearest = vehicle
    return nearest

func _toggle_vehicle() -> void:
    if current_vehicle != null:
        var exit_offset := current_vehicle.global_transform.basis.x * 2.2
        player.global_position = current_vehicle.global_position + exit_offset + Vector3(0, 0.2, 0)
        player.visible = true
        player.get_node("CollisionShape3D").set_deferred("disabled", false)
        current_vehicle = null
        _show_message("Você saiu do veículo.")
    else:
        var candidate := _nearest_vehicle()
        if candidate == null:
            _show_message("Chegue perto de um carro ou viatura para entrar.")
            return
        current_vehicle = candidate
        player.visible = false
        player.get_node("CollisionShape3D").set_deferred("disabled", true)
        var name := str(candidate.get_meta("vehicle_name", "veículo"))
        _show_message("Você entrou no %s. Use os controles para dirigir." % name)
    if vehicle_button != null:
        vehicle_button.text = "SAIR DO VEÍCULO" if current_vehicle != null else "ENTRAR NO VEÍCULO"

func _build_hud() -> void:
    var layer := CanvasLayer.new()
    add_child(layer)
    var top := PanelContainer.new()
    top.position = Vector2(14, 12)
    top.custom_minimum_size = Vector2(320, 62)
    layer.add_child(top)
    var stack := VBoxContainer.new()
    top.add_child(stack)
    var title := Label.new()
    title.text = "CIDADE 49 RP  •  " + player_name
    title.add_theme_color_override("font_color", Color("#f2bd65"))
    title.add_theme_font_size_override("font_size", 17)
    stack.add_child(title)
    hud_info = Label.new()
    hud_info.text = "DINHEIRO: $%d  •  BANCO: $%d  •  BAIRRO 49" % [money, bank_balance]
    stack.add_child(hud_info)

    var menu := Button.new()
    menu.text = "MENU"
    menu.position = Vector2(1100, 14)
    menu.custom_minimum_size = Vector2(150, 48)
    menu.pressed.connect(func():
        _save_game()
        get_tree().change_scene_to_file("res://scenes/MainMenu.tscn")
    )
    layer.add_child(menu)

    _add_touch_button(layer, "▲", Vector2(95, 535), "up")
    _add_touch_button(layer, "▼", Vector2(95, 645), "down")
    _add_touch_button(layer, "◀", Vector2(35, 590), "left")
    _add_touch_button(layer, "▶", Vector2(155, 590), "right")

    var job_btn := Button.new()
    job_btn.text = "TRABALHAR: ENTREGA"
    job_btn.position = Vector2(990, 500)
    job_btn.custom_minimum_size = Vector2(200, 52)
    job_btn.pressed.connect(_toggle_delivery)
    layer.add_child(job_btn)

    var police_btn := Button.new()
    police_btn.text = "PAGAR MULTA / DELEGACIA"
    police_btn.position = Vector2(990, 558)
    police_btn.custom_minimum_size = Vector2(200, 52)
    police_btn.add_theme_font_size_override("font_size", 12)
    police_btn.pressed.connect(_station_action)
    layer.add_child(police_btn)

    vehicle_button = Button.new()
    vehicle_button.text = "ENTRAR NO VEÍCULO"
    vehicle_button.position = Vector2(990, 616)
    vehicle_button.custom_minimum_size = Vector2(200, 52)
    vehicle_button.pressed.connect(_toggle_vehicle)
    layer.add_child(vehicle_button)

    message_label = Label.new()
    message_label.position = Vector2(340, 620)
    message_label.custom_minimum_size = Vector2(560, 50)
    message_label.horizontal_alignment = HORIZONTAL_ALIGNMENT_CENTER
    message_label.add_theme_color_override("font_color", Color("#ffe0a3"))
    message_label.text = "Explore o bairro. Use WASD, as setas ou os controles na tela."
    layer.add_child(message_label)

    var note := Label.new()
    note.text = "PROTÓTIPO 3D OFFLINE"
    note.position = Vector2(16, 88)
    note.add_theme_font_size_override("font_size", 12)
    note.add_theme_color_override("font_color", Color("#dce6f2"))
    layer.add_child(note)

func _add_touch_button(layer: CanvasLayer, caption: String, pos: Vector2, direction: String) -> void:
    var button := Button.new()
    button.text = caption
    button.position = pos
    button.custom_minimum_size = Vector2(54, 54)
    button.add_theme_font_size_override("font_size", 22)
    button.button_down.connect(func(): touch_dirs[direction] = true)
    button.button_up.connect(func(): touch_dirs[direction] = false)
    layer.add_child(button)

func _unhandled_input(event: InputEvent) -> void:
    if event is InputEventScreenDrag and event.position.x > 240:
        # Arrastar o lado direito gira o personagem ou o veículo que está sendo dirigido.
        if current_vehicle != null:
            current_vehicle.rotate_y(-event.relative.x * 0.004)
        else:
            player.rotate_y(-event.relative.x * 0.004)

func _physics_process(delta: float) -> void:
    if player == null:
        return
    if jail_timer > 0.0:
        jail_timer = maxf(0.0, jail_timer - delta)
        if jail_timer == 0.0:
            wanted = false
            fine_due = 0
            _show_message("Você foi liberado da delegacia.")

    var x := float(Input.is_key_pressed(KEY_D) or Input.is_key_pressed(KEY_RIGHT) or touch_dirs["right"]) - float(Input.is_key_pressed(KEY_A) or Input.is_key_pressed(KEY_LEFT) or touch_dirs["left"])
    var z := float(Input.is_key_pressed(KEY_S) or Input.is_key_pressed(KEY_DOWN) or touch_dirs["down"]) - float(Input.is_key_pressed(KEY_W) or Input.is_key_pressed(KEY_UP) or touch_dirs["up"])
    var raw := Vector2(x, z).limit_length(1.0)

    if Input.is_key_just_pressed(KEY_E):
        _toggle_vehicle()

    if current_vehicle != null:
        var throttle := -raw.y
        var max_speed := float(current_vehicle.get_meta("max_speed", 16.0))
        if jail_timer > 0.0:
            throttle = 0.0
        if absf(throttle) > 0.05:
            current_vehicle.rotate_y(-raw.x * delta * 1.45 * signf(throttle))
        var desired := -current_vehicle.global_transform.basis.z * throttle * max_speed
        current_vehicle.velocity.x = move_toward(current_vehicle.velocity.x, desired.x, 22.0 * delta)
        current_vehicle.velocity.z = move_toward(current_vehicle.velocity.z, desired.z, 22.0 * delta)
        if not current_vehicle.is_on_floor():
            current_vehicle.velocity.y -= GRAVITY * delta
        else:
            current_vehicle.velocity.y = -0.2
        current_vehicle.move_and_slide()
        _update_camera(current_vehicle.global_position, current_vehicle.global_transform.basis)
    else:
        var forward := -player.global_transform.basis.z
        var right := player.global_transform.basis.x
        var direction := (right * raw.x + forward * -raw.y).normalized()
        if jail_timer > 0.0:
            direction = Vector3.ZERO
        var speed := RUN_SPEED if Input.is_key_pressed(KEY_SHIFT) else WALK_SPEED
        player.velocity.x = direction.x * speed
        player.velocity.z = direction.z * speed
        if not player.is_on_floor():
            player.velocity.y -= GRAVITY * delta
        else:
            player.velocity.y = -0.2
        player.move_and_slide()
        if direction.length() > 0.1:
            var target_angle := atan2(-direction.x, -direction.z)
            player.rotation.y = lerp_angle(player.rotation.y, target_angle, delta * 8.0)
        _update_camera(player.global_position, player.global_transform.basis)

    var active_position := current_vehicle.global_position if current_vehicle != null else player.global_position
    var inside := Vector2(active_position.x, active_position.z).distance_to(Vector2(RESTRICTED_CENTER.x, RESTRICTED_CENTER.z)) < 7.0
    if inside and not in_restricted_area and not wanted:
        wanted = true
        fine_due = 250
        _show_message("Alerta: área restrita! Regularize sua situação na delegacia.")
    in_restricted_area = inside

    if mission_active and current_vehicle == null:
        var target := PICKUP_POINT if mission_stage == 0 else DROP_POINT
        var dist := Vector2(player.global_position.x, player.global_position.z).distance_to(Vector2(target.x, target.z))
        if dist < 2.5:
            if mission_stage == 0:
                mission_stage = 1
                _show_message("Pacote retirado! Siga até o destino verde.")
            else:
                mission_active = false
                money += mission_reward
                _save_game()
                _show_message("Entrega concluída! Você recebeu $%d." % mission_reward)
            _refresh_hud()
    if hud_info != null:
        var vehicle_status := " • DIRIGINDO" if current_vehicle != null else ""
        hud_info.text = "DINHEIRO: $%d  •  BANCO: $%d  •  %s%s" % [money, bank_balance, "PROCURADO" if wanted else "BAIRRO 49", vehicle_status]
    if interaction_button != null:
        var nearby := _nearest_interaction()
        interaction_button.disabled = nearby.is_empty()
        if inside_house:
            interaction_button.text = "SAIR DA CASA"
        elif nearby.is_empty():
            interaction_button.text = "INTERAGIR"
        else:
            interaction_button.text = "INTERAGIR: %s" % str(nearby.get("name", "LOCAL")).to_upper()

func _update_camera(target_position: Vector3, target_basis: Basis) -> void:
    var desired_position := target_position + target_basis * Vector3(0, 4.6, 8.8)
    camera.global_position = camera.global_position.lerp(desired_position, 5.0 * get_physics_process_delta_time())
    camera.look_at(target_position + Vector3(0, 1.15, 0), Vector3.UP)

func _toggle_delivery() -> void:
    if mission_active:
        mission_active = false
        _show_message("Entrega cancelada.")
    else:
        mission_active = true
        mission_stage = 0
        _show_message("Entrega aceita! Vá ao ponto de retirada amarelo.")
    _refresh_hud()

func _station_action() -> void:
    var actor_position := current_vehicle.global_position if current_vehicle != null else player.global_position
    var dist := Vector2(actor_position.x - STATION_POINT.x, actor_position.z - STATION_POINT.z).length()
    if dist > 8.0:
        _show_message("Vá até a delegacia para regularizar sua situação.")
    elif wanted:
        if money >= fine_due:
            money -= fine_due
            _save_game()
            wanted = false
            fine_due = 0
            _show_message("Multa paga. Situação regularizada.")
        else:
            jail_timer = 12.0
            _show_message("Saldo insuficiente. Aguarde 12 segundos na delegacia.")
    else:
        _show_message("Delegacia: nenhuma pendência encontrada.")
    _refresh_hud()

func _refresh_hud() -> void:
    if hud_info != null:
        hud_info.text = "DINHEIRO: $%d  •  BANCO: $%d  •  %s" % [money, bank_balance, "PROCURADO" if wanted else "BAIRRO 49"]

func _show_message(value: String) -> void:
    if message_label != null:
        message_label.text = value
