extends Node2D

var player: CharacterBody2D
var held := {"up": false, "down": false, "left": false, "right": false}
var player_name := "Morador"
var outfit := Color("#3d8fbd")
var hud_label: Label
var money_label: Label
var job_status: Label
var job_button: Button
var delivery_job: DeliveryJob
var bike_visual: Node2D
var vehicle_owned := false
var vehicle_active := false
var fuel := 100.0
var fuel_label: Label
var vehicle_button: Button
var garage_button: Button
var police_button: Button
var station_button: Button
var wanted_label: Label
var police_system: PoliceSystem
var was_inside_restricted_area := false
const STATION_POSITION := Vector2(190, 540)
const RESTRICTED_POSITION := Vector2(970, 140)
const RESTRICTED_RADIUS := 72.0
const GARAGE_POSITION := Vector2(1080, 150)
const VEHICLE_PRICE := 1000
const REFUEL_PRICE := 50

func _ready() -> void:
    _load_character()
    delivery_job = DeliveryJob.new()
    add_child(delivery_job)
    delivery_job.job_updated.connect(_on_job_updated)
    delivery_job.money_earned.connect(_on_money_earned)
    police_system = PoliceSystem.new()
    add_child(police_system)
    police_system.status_changed.connect(_on_police_status_changed)
    police_system.reward_earned.connect(_on_police_reward_earned)
    _build_world()
    _build_player()
    _build_hud()

func _load_character() -> void:
    var cfg := ConfigFile.new()
    if cfg.load("user://cidade49.cfg") == OK:
        player_name = str(cfg.get_value("personagem", "nome", "Morador"))
        var palette := [Color("#3d8fbd"), Color("#b85c45"), Color("#4b9b68"), Color("#9a72c4")]
        outfit = palette[int(cfg.get_value("personagem", "cor", 0)) % palette.size()]

func _build_world() -> void:
    queue_redraw()

func _draw() -> void:
    var view := get_viewport_rect().size
    draw_rect(Rect2(Vector2.ZERO, view), Color("#506b58"))
    # ruas e quadras estilizadas para o primeiro protótipo 2D
    draw_rect(Rect2(Vector2(view.x * 0.36, 0), Vector2(view.x * 0.22, view.y)), Color("#343d49"))
    draw_rect(Rect2(Vector2(0, view.y * 0.43), Vector2(view.x, view.y * 0.20)), Color("#343d49"))
    for y in range(0, int(view.y), 72):
        draw_line(Vector2(view.x * 0.47, y), Vector2(view.x * 0.47, y + 32), Color("#e4d6a2"), 3)
    for x in range(0, int(view.x), 72):
        draw_line(Vector2(x, view.y * 0.53), Vector2(x + 32, view.y * 0.53), Color("#e4d6a2"), 3)
    # casas coloridas dos dois lados da rua
    for i in range(5):
        var x := 24.0 + i * 105.0
        draw_rect(Rect2(Vector2(x, 34), Vector2(72, 58)), Color("#bd8762"))
        draw_rect(Rect2(Vector2(x, 108), Vector2(72, 58)), Color("#d0b17b"))
        draw_rect(Rect2(Vector2(x, view.y - 112), Vector2(72, 64)), Color("#a66d58"))
        draw_rect(Rect2(Vector2(x, view.y - 190), Vector2(72, 64)), Color("#c39a69"))
        draw_rect(Rect2(Vector2(x + 28, 52), Vector2(16, 20)), Color("#f4d68b"))
    # Delegacia e área restrita do protótipo
    draw_rect(Rect2(STATION_POSITION - Vector2(62, 42), Vector2(124, 84)), Color("#647789"))
    draw_rect(Rect2(STATION_POSITION - Vector2(46, 27), Vector2(92, 54)), Color("#263746"))
    draw_rect(Rect2(STATION_POSITION - Vector2(20, 35), Vector2(40, 16)), Color("#e8edf2"))
    draw_string(ThemeDB.fallback_font, STATION_POSITION + Vector2(-38, 58), "DELEGACIA", HORIZONTAL_ALIGNMENT_LEFT, 110, 13, Color.WHITE)
    draw_circle(RESTRICTED_POSITION, RESTRICTED_RADIUS, Color(0.85, 0.25, 0.20, 0.16))
    draw_arc(RESTRICTED_POSITION, RESTRICTED_RADIUS, 0.0, TAU, 48, Color("#ef8b70"), 3.0)
    draw_string(ThemeDB.fallback_font, RESTRICTED_POSITION + Vector2(-55, -85), "ÁREA RESTRITA", HORIZONTAL_ALIGNMENT_LEFT, 130, 13, Color.WHITE)
    if police_system != null and police_system.on_duty:
        var patrol_marker := police_system.get_patrol_marker()
        draw_circle(patrol_marker, 25, Color(0.20, 0.55, 1.0, 0.22))
        draw_circle(patrol_marker, 15, Color("#64b5ff"))
        draw_circle(patrol_marker, 6, Color.WHITE)
        draw_string(ThemeDB.fallback_font, patrol_marker + Vector2(-30, -32), "PATRULHA", HORIZONTAL_ALIGNMENT_LEFT, 100, 13, Color.WHITE)
    # Garagem do bairro: ponto de compra e abastecimento
    draw_rect(Rect2(GARAGE_POSITION - Vector2(58, 38), Vector2(116, 76)), Color("#596b7a"))
    draw_rect(Rect2(GARAGE_POSITION - Vector2(43, 25), Vector2(86, 50)), Color("#263746"))
    draw_rect(Rect2(GARAGE_POSITION - Vector2(30, 15), Vector2(60, 30)), Color("#d6a85f"))
    draw_string(ThemeDB.fallback_font, GARAGE_POSITION + Vector2(-38, 55), "GARAGEM", HORIZONTAL_ALIGNMENT_LEFT, 100, 13, Color.WHITE)
    draw_string(ThemeDB.fallback_font, Vector2(20, view.y - 18), "BAIRRO 49 • ÁREA DE TESTE", HORIZONTAL_ALIGNMENT_LEFT, -1, 14, Color.WHITE)
    if delivery_job != null and delivery_job.is_active():
        var marker := delivery_job.get_marker()
        var marker_color := Color("#f2bd65") if delivery_job.stage == DeliveryJob.Stage.PICKUP else Color("#6fe0a1")
        draw_circle(marker, 27, Color(marker_color, 0.22))
        draw_circle(marker, 17, marker_color)
        draw_circle(marker, 7, Color.WHITE)
        var marker_text := "RETIRADA" if delivery_job.stage == DeliveryJob.Stage.PICKUP else "DESTINO"
        draw_string(ThemeDB.fallback_font, marker + Vector2(-34, -34), marker_text, HORIZONTAL_ALIGNMENT_LEFT, 110, 14, Color.WHITE)

func _build_player() -> void:
    player = CharacterBody2D.new()
    player.position = get_viewport_rect().size * 0.5
    add_child(player)
    var shape := CollisionShape2D.new()
    var circle := CircleShape2D.new()
    circle.radius = 15
    shape.shape = circle
    player.add_child(shape)

    bike_visual = Node2D.new()
    bike_visual.visible = false
    player.add_child(bike_visual)
    for wheel_x in [-22.0, 22.0]:
        var wheel := Polygon2D.new()
        var wheel_points := PackedVector2Array()
        for i in range(12):
            var angle := TAU * float(i) / 12.0
            wheel_points.append(Vector2(cos(angle), sin(angle)) * 9.0)
        wheel.polygon = wheel_points
        wheel.position = Vector2(wheel_x, 7)
        wheel.color = Color("#17202b")
        bike_visual.add_child(wheel)
    var bike_body := Polygon2D.new()
    bike_body.polygon = PackedVector2Array([Vector2(-28, -4), Vector2(-15, -13), Vector2(17, -13), Vector2(29, 1), Vector2(14, 10), Vector2(-20, 10)])
    bike_body.color = Color("#e6a13c")
    bike_visual.add_child(bike_body)

    var visual := Polygon2D.new()
    visual.polygon = PackedVector2Array([Vector2(-12,-10), Vector2(12,-10), Vector2(15,13), Vector2(-15,13)])
    visual.color = outfit
    player.add_child(visual)
    var head := Polygon2D.new()
    head.polygon = PackedVector2Array([Vector2(-8,-27), Vector2(8,-27), Vector2(10,-11), Vector2(-10,-11)])
    head.color = Color("#bd8c69")
    player.add_child(head)

func _build_hud() -> void:
    var layer := CanvasLayer.new()
    add_child(layer)
    var top := PanelContainer.new()
    top.position = Vector2(16, 14)
    top.custom_minimum_size = Vector2(280, 54)
    layer.add_child(top)
    hud_label = Label.new()
    hud_label.text = "  CIDADE 49 RP  •  " + player_name
    hud_label.add_theme_color_override("font_color", Color("#f2bd65"))
    hud_label.add_theme_font_size_override("font_size", 17)
    top.add_child(hud_label)

    var back := Button.new()
    back.text = "MENU"
    back.position = Vector2(get_viewport_rect().size.x - 112, 16)
    back.custom_minimum_size = Vector2(96, 48)
    back.pressed.connect(func(): get_tree().change_scene_to_file("res://scenes/MainMenu.tscn"))
    layer.add_child(back)

    _add_touch_button(layer, "▲", Vector2(92, get_viewport_rect().size.y - 178), "up")
    _add_touch_button(layer, "▼", Vector2(92, get_viewport_rect().size.y - 78), "down")
    _add_touch_button(layer, "◀", Vector2(34, get_viewport_rect().size.y - 128), "left")
    _add_touch_button(layer, "▶", Vector2(150, get_viewport_rect().size.y - 128), "right")

    money_label = Label.new()
    money_label.text = "DINHEIRO: $%d" % delivery_job.money
    money_label.position = Vector2(18, 48)
    money_label.add_theme_font_size_override("font_size", 16)
    money_label.add_theme_color_override("font_color", Color("#8ff0b1"))
    layer.add_child(money_label)

    job_status = Label.new()
    job_status.text = delivery_job.get_stage_name()
    job_status.position = Vector2(18, 104)
    job_status.add_theme_font_size_override("font_size", 14)
    job_status.add_theme_color_override("font_color", Color("#f2bd65"))
    layer.add_child(job_status)

    job_button = Button.new()
    job_button.text = "INICIAR ENTREGA"
    job_button.position = Vector2(get_viewport_rect().size.x - 230, 78)
    job_button.custom_minimum_size = Vector2(210, 54)
    job_button.add_theme_font_size_override("font_size", 15)
    job_button.pressed.connect(_on_job_button_pressed)
    layer.add_child(job_button)

    vehicle_button = Button.new()
    vehicle_button.text = "COMPRAR VEÍCULO" if not vehicle_owned else "ENTRAR NA MOTO"
    vehicle_button.position = Vector2(get_viewport_rect().size.x - 230, 142)
    vehicle_button.custom_minimum_size = Vector2(210, 48)
    vehicle_button.add_theme_font_size_override("font_size", 14)
    vehicle_button.pressed.connect(_on_vehicle_button_pressed)
    layer.add_child(vehicle_button)

    garage_button = Button.new()
    garage_button.text = "GARAGEM / ABASTECER"
    garage_button.position = Vector2(get_viewport_rect().size.x - 230, 198)
    garage_button.custom_minimum_size = Vector2(210, 48)
    garage_button.add_theme_font_size_override("font_size", 13)
    garage_button.pressed.connect(_on_garage_button_pressed)
    layer.add_child(garage_button)

    fuel_label = Label.new()
    fuel_label.text = "COMBUSTÍVEL: 100%"
    fuel_label.position = Vector2(18, 128)
    fuel_label.add_theme_font_size_override("font_size", 14)
    fuel_label.add_theme_color_override("font_color", Color("#f2bd65"))
    layer.add_child(fuel_label)

    wanted_label = Label.new()
    wanted_label.text = police_system.get_status_text()
    wanted_label.position = Vector2(18, 154)
    wanted_label.add_theme_font_size_override("font_size", 13)
    wanted_label.add_theme_color_override("font_color", Color("#ffb0a0"))
    layer.add_child(wanted_label)

    police_button = Button.new()
    police_button.text = "INICIAR TURNO POLICIAL"
    police_button.position = Vector2(get_viewport_rect().size.x - 230, 254)
    police_button.custom_minimum_size = Vector2(210, 48)
    police_button.add_theme_font_size_override("font_size", 13)
    police_button.pressed.connect(_on_police_button_pressed)
    layer.add_child(police_button)

    station_button = Button.new()
    station_button.text = "DELEGACIA / REGULARIZAR"
    station_button.position = Vector2(get_viewport_rect().size.x - 230, 310)
    station_button.custom_minimum_size = Vector2(210, 48)
    station_button.add_theme_font_size_override("font_size", 12)
    station_button.pressed.connect(_on_station_button_pressed)
    layer.add_child(station_button)

    var notice := Label.new()
    notice.text = "PROTÓTIPO OFFLINE • USE AS SETAS OU O CONTROLE NA TELA"
    notice.position = Vector2(18, 78)
    notice.add_theme_font_size_override("font_size", 12)
    notice.add_theme_color_override("font_color", Color("#ffffff"))
    layer.add_child(notice)

func _add_touch_button(layer: CanvasLayer, caption: String, pos: Vector2, direction: String) -> void:
    var b := Button.new()
    b.text = caption
    b.position = pos
    b.custom_minimum_size = Vector2(54, 54)
    b.add_theme_font_size_override("font_size", 22)
    b.button_down.connect(func(): held[direction] = true)
    b.button_up.connect(func(): held[direction] = false)
    layer.add_child(b)

func _physics_process(_delta: float) -> void:
    if player == null:
        return
    police_system.tick(_delta)
    if wanted_label != null:
        wanted_label.text = police_system.get_status_text()
    if police_button != null:
        police_button.text = "ENCERRAR TURNO POLICIAL" if police_system.on_duty else "INICIAR TURNO POLICIAL"
    if police_system.is_jailed():
        player.velocity = Vector2.ZERO
        if fuel_label != null:
            fuel_label.text = "CUSTÓDIA: %ds" % int(ceil(police_system.jail_remaining))
        queue_redraw()
        return
    var keyboard := Vector2.ZERO
    keyboard.x = float(Input.is_key_pressed(KEY_RIGHT) or Input.is_key_pressed(KEY_D)) - float(Input.is_key_pressed(KEY_LEFT) or Input.is_key_pressed(KEY_A))
    keyboard.y = float(Input.is_key_pressed(KEY_DOWN) or Input.is_key_pressed(KEY_S)) - float(Input.is_key_pressed(KEY_UP) or Input.is_key_pressed(KEY_W))
    var touch := Vector2(float(held["right"]) - float(held["left"]), float(held["down"]) - float(held["up"]))
    var direction := (keyboard + touch).limit_length(1.0)
    var movement_speed := 230.0
    if vehicle_active:
        movement_speed = 420.0
        fuel = maxf(0.0, fuel - _delta * 1.25)
        if fuel <= 0.0:
            vehicle_active = false
            _set_vehicle_message("Combustível acabou! Vá à garagem abastecer.")
    elif delivery_job != null and delivery_job.is_active():
        movement_speed = 300.0
    if bike_visual != null:
        bike_visual.visible = vehicle_active or (delivery_job != null and delivery_job.is_active())
    if fuel_label != null:
        fuel_label.text = "COMBUSTÍVEL: %d%%" % int(fuel)
    player.velocity = direction * movement_speed
    player.move_and_slide()
    if delivery_job != null:
        delivery_job.update_player_position(player.position)
    police_system.update_position(player.position)
    var inside_restricted := player.position.distance_to(RESTRICTED_POSITION) <= RESTRICTED_RADIUS
    if inside_restricted and not was_inside_restricted_area:
        police_system.enter_restricted_area()
    was_inside_restricted_area = inside_restricted
    var bounds := get_viewport_rect().size
    player.position.x = clamp(player.position.x, 18.0, bounds.x - 18.0)
    player.position.y = clamp(player.position.y, 18.0, bounds.y - 18.0)


func _on_job_button_pressed() -> void:
    if delivery_job.is_active():
        delivery_job.cancel()
    else:
        delivery_job.start()
    _refresh_job_hud()
    queue_redraw()

func _on_job_updated(message: String) -> void:
    if job_status != null:
        job_status.text = message
    if job_button != null:
        job_button.text = "CANCELAR ENTREGA" if delivery_job.is_active() else "INICIAR ENTREGA"
    queue_redraw()

func _on_money_earned(_amount: int, total: int) -> void:
    if money_label != null:
        money_label.text = "DINHEIRO: $%d" % total

func _refresh_job_hud() -> void:
    if job_status != null:
        job_status.text = delivery_job.get_stage_name()
    if job_button != null:
        job_button.text = "CANCELAR ENTREGA" if delivery_job.is_active() else "INICIAR ENTREGA"


func _on_vehicle_button_pressed() -> void:
    if not vehicle_owned:
        _set_vehicle_message("Visite a GARAGEM no mapa para comprar uma moto por $%d." % VEHICLE_PRICE)
        return
    if vehicle_active:
        vehicle_active = false
        _set_vehicle_message("Você saiu da moto.")
    elif fuel <= 0.0:
        _set_vehicle_message("Sem combustível. Abasteça na garagem.")
    else:
        vehicle_active = true
        _set_vehicle_message("Você está pilotando! Use os controles para dirigir.")
    _refresh_vehicle_hud()

func _on_garage_button_pressed() -> void:
    if player.global_position.distance_to(GARAGE_POSITION) > 105.0:
        _set_vehicle_message("Chegue perto da GARAGEM indicada no mapa para comprar ou abastecer.")
        return
    if not vehicle_owned:
        if delivery_job.money < VEHICLE_PRICE:
            _set_vehicle_message("A moto custa $%d. Faça entregas para juntar dinheiro." % VEHICLE_PRICE)
            return
        delivery_job.money -= VEHICLE_PRICE
        vehicle_owned = true
        fuel = 100.0
        _set_vehicle_message("Moto comprada! Agora você pode entrar nela.")
    elif fuel < 100.0:
        if delivery_job.money < REFUEL_PRICE:
            _set_vehicle_message("Você precisa de $%d para abastecer." % REFUEL_PRICE)
            return
        delivery_job.money -= REFUEL_PRICE
        fuel = 100.0
        _set_vehicle_message("Tanque cheio! Foram cobrados $%d." % REFUEL_PRICE)
    else:
        _set_vehicle_message("Sua moto está guardada aqui e o tanque está cheio.")
    _on_money_earned(0, delivery_job.money)
    _refresh_vehicle_hud()

func _set_vehicle_message(message: String) -> void:
    if job_status != null:
        job_status.text = message

func _refresh_vehicle_hud() -> void:
    if vehicle_button != null:
        if not vehicle_owned:
            vehicle_button.text = "COMPRAR VEÍCULO"
        else:
            vehicle_button.text = "SAIR DA MOTO" if vehicle_active else "ENTRAR NA MOTO"
    if fuel_label != null:
        fuel_label.text = "COMBUSTÍVEL: %d%%" % int(fuel)


func _on_police_status_changed(message: String) -> void:
    if job_status != null:
        job_status.text = message
    if wanted_label != null:
        wanted_label.text = police_system.get_status_text()
    if police_button != null:
        police_button.text = "ENCERRAR TURNO POLICIAL" if police_system.on_duty else "INICIAR TURNO POLICIAL"
    queue_redraw()

func _on_police_reward_earned(amount: int) -> void:
    delivery_job.money += amount
    if money_label != null:
        money_label.text = "DINHEIRO: $%d" % delivery_job.money

func _on_police_button_pressed() -> void:
    if player.global_position.distance_to(STATION_POSITION) > 115.0:
        _set_vehicle_message("Vá até a DELEGACIA no mapa para iniciar ou encerrar o turno policial.")
        return
    if police_system.on_duty:
        police_system.end_shift()
    else:
        police_system.start_shift()
    queue_redraw()

func _on_station_button_pressed() -> void:
    if player.global_position.distance_to(STATION_POSITION) > 115.0:
        _set_vehicle_message("Chegue perto da DELEGACIA para pagar multas ou regularizar sua situação.")
        return
    var paid := police_system.settle_at_station(delivery_job.money)
    if paid > 0:
        delivery_job.money -= paid
        if money_label != null:
            money_label.text = "DINHEIRO: $%d" % delivery_job.money
    queue_redraw()
