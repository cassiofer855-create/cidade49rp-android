extends Node
class_name PoliceSystem

signal status_changed(message: String)
signal reward_earned(amount: int)

const STATION_POSITION := Vector2(190, 540)
const PATROL_POINTS := [Vector2(390, 120), Vector2(790, 300), Vector2(1080, 610)]
const PATROL_REWARD := 100
const WANTED_FINE := 250
const JAIL_SECONDS := 12.0
const CHECKPOINT_RADIUS := 48.0

var on_duty := false
var patrol_index := 0
var wanted_level := 0
var fine_due := 0
var jail_remaining := 0.0

func start_shift() -> void:
    if on_duty:
        status_changed.emit("Você já está em serviço. Visite os pontos de patrulha.")
        return
    on_duty = true
    patrol_index = 0
    status_changed.emit("Turno iniciado! Visite os 3 pontos marcados no mapa.")

func end_shift() -> void:
    if not on_duty:
        return
    on_duty = false
    status_changed.emit("Turno policial encerrado.")

func update_position(position: Vector2) -> void:
    if not on_duty or patrol_index >= PATROL_POINTS.size():
        return
    if position.distance_to(PATROL_POINTS[patrol_index]) <= CHECKPOINT_RADIUS:
        reward_earned.emit(PATROL_REWARD)
        patrol_index += 1
        if patrol_index >= PATROL_POINTS.size():
            on_duty = false
            status_changed.emit("Patrulha concluída! Você recebeu todas as recompensas.")
        else:
            status_changed.emit("Ponto vistoriado! Siga para o próximo local.")

func get_patrol_marker() -> Vector2:
    if on_duty and patrol_index < PATROL_POINTS.size():
        return PATROL_POINTS[patrol_index]
    return Vector2(-1000, -1000)

func enter_restricted_area() -> void:
    if wanted_level > 0 or jail_remaining > 0.0:
        return
    wanted_level = 1
    fine_due = WANTED_FINE
    status_changed.emit("Alerta de procurado! Vá à delegacia para regularizar a situação.")

func settle_at_station(current_money: int) -> int:
    if wanted_level <= 0:
        status_changed.emit("Nenhuma pendência. A delegacia está tranquila.")
        return 0
    if current_money >= fine_due:
        var paid := fine_due
        wanted_level = 0
        fine_due = 0
        status_changed.emit("Multa paga: $%d. Situação regularizada." % paid)
        return paid
    jail_remaining = JAIL_SECONDS * float(wanted_level)
    status_changed.emit("Saldo insuficiente. Aguarde na delegacia por %d segundos." % int(jail_remaining))
    return 0

func tick(delta: float) -> void:
    if jail_remaining <= 0.0:
        return
    jail_remaining = maxf(0.0, jail_remaining - delta)
    if jail_remaining <= 0.0:
        wanted_level = 0
        fine_due = 0
        status_changed.emit("Período cumprido. Você está liberado.")

func is_jailed() -> bool:
    return jail_remaining > 0.0

func get_status_text() -> String:
    if jail_remaining > 0.0:
        return "DETIDO: %ds" % int(ceil(jail_remaining))
    if wanted_level > 0:
        return "PROCURADO: %d estrela(s) • MULTA $%d" % [wanted_level, fine_due]
    return "SEM PENDÊNCIAS"
