extends Node
class_name DeliveryJob

signal job_updated(message: String)
signal money_earned(amount: int, total: int)

const PICKUP := Vector2(190, 205)
const DROPOFF := Vector2(1080, 545)
const REWARD := 150
const ARRIVAL_DISTANCE := 42.0

enum Stage { IDLE, PICKUP, DROPOFF }

var stage: Stage = Stage.IDLE
var money: int = 500

func start() -> void:
	if stage != Stage.IDLE:
		job_updated.emit("Você já está em uma entrega. Vá até o marcador!")
		return
	stage = Stage.PICKUP
	job_updated.emit("Entrega aceita! Vá buscar o pacote no ponto amarelo.")

func cancel() -> void:
	if stage == Stage.IDLE:
		return
	stage = Stage.IDLE
	job_updated.emit("Entrega cancelada. Nenhuma recompensa foi paga.")

func update_player_position(player_position: Vector2) -> void:
	if stage == Stage.PICKUP and player_position.distance_to(PICKUP) <= ARRIVAL_DISTANCE:
		stage = Stage.DROPOFF
		job_updated.emit("Pacote retirado! Leve ao destino marcado em verde.")
	elif stage == Stage.DROPOFF and player_position.distance_to(DROPOFF) <= ARRIVAL_DISTANCE:
		money += REWARD
		stage = Stage.IDLE
		money_earned.emit(REWARD, money)
		job_updated.emit("Entrega concluída! Você recebeu $%d." % REWARD)

func get_marker() -> Vector2:
	if stage == Stage.PICKUP:
		return PICKUP
	if stage == Stage.DROPOFF:
		return DROPOFF
	return Vector2(-1000, -1000)

func get_stage_name() -> String:
	match stage:
		Stage.PICKUP:
			return "BUSCAR PACOTE"
		Stage.DROPOFF:
			return "ENTREGAR PACOTE"
		_:
			return "SEM ENTREGA ATIVA"

func is_active() -> bool:
	return stage != Stage.IDLE
