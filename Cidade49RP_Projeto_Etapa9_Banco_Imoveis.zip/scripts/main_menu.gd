extends Control

var panel: PanelContainer
var status_label: Label
var settings_popup: AcceptDialog
var customize_popup: AcceptDialog

func _ready() -> void:
    _build_background()
    _build_interface()

func _build_background() -> void:
    var bg = ColorRect.new()
    bg.color = Color("#101827")
    bg.set_anchors_and_offsets_preset(Control.PRESET_FULL_RECT)
    add_child(bg)

    var skyline = Control.new()
    skyline.set_anchors_and_offsets_preset(Control.PRESET_FULL_RECT)
    skyline.mouse_filter = Control.MOUSE_FILTER_IGNORE
    skyline.draw.connect(func():
        var w = skyline.size.x
        var h = skyline.size.y
        skyline.draw_rect(Rect2(0, h * 0.58, w, h * 0.42), Color("#172538"))
        # Morros e casas estilizadas ao fundo
        skyline.draw_colored_polygon(PackedVector2Array([
            Vector2(0,h*0.62), Vector2(w*0.24,h*0.30), Vector2(w*0.48,h*0.63)
        ]), Color("#263b4b"))
        skyline.draw_colored_polygon(PackedVector2Array([
            Vector2(w*0.42,h*0.64), Vector2(w*0.70,h*0.25), Vector2(w,h*0.62)
        ]), Color("#203449"))
        for i in range(18):
            var x = float(i) * w / 18.0
            var bh = 55 + float((i * 37) % 130)
            skyline.draw_rect(Rect2(x, h*0.69-bh, w/22, bh), Color("#1b2c3e"))
            for j in range(3):
                skyline.draw_rect(Rect2(x+7+j*12, h*0.69-bh+14, 5, 7), Color("#e8b968", 0.65))
        # luzes nas casas do morro
        for i in range(90):
            var x = float((i*73) % 1200) / 1200.0 * w
            var y = h * (0.38 + float((i*19)%230)/1000.0)
            skyline.draw_circle(Vector2(x,y), 2.2, Color("#ffc96b", 0.8))
        skyline.draw_rect(Rect2(0,h*0.69,w,h*0.31), Color("#0c1420",0.72))
    )
    add_child(skyline)
    skyline.queue_redraw()

func _build_interface() -> void:
    var shade = ColorRect.new()
    shade.color = Color(0.02, 0.04, 0.08, 0.35)
    shade.set_anchors_and_offsets_preset(Control.PRESET_FULL_RECT)
    add_child(shade)

    var content = VBoxContainer.new()
    content.anchor_left = 0.08
    content.anchor_top = 0.10
    content.anchor_right = 0.52
    content.anchor_bottom = 0.90
    content.add_theme_constant_override("separation", 14)
    add_child(content)

    var eyebrow = Label.new()
    eyebrow.text = "BRASIL • MUNDO ABERTO • ROLEPLAY"
    eyebrow.add_theme_font_size_override("font_size", 16)
    eyebrow.add_theme_color_override("font_color", Color("#f2bd65"))
    content.add_child(eyebrow)

    var title = Label.new()
    title.text = "CIDADE 49"
    title.add_theme_font_size_override("font_size", 64)
    title.add_theme_color_override("font_color", Color.WHITE)
    title.add_theme_color_override("font_shadow_color", Color("#000000"))
    title.add_theme_constant_override("shadow_offset_x", 3)
    title.add_theme_constant_override("shadow_offset_y", 4)
    content.add_child(title)

    var subtitle = Label.new()
    subtitle.text = "RP"
    subtitle.add_theme_font_size_override("font_size", 34)
    subtitle.add_theme_color_override("font_color", Color("#f2bd65"))
    content.add_child(subtitle)

    var spacer = Control.new()
    spacer.custom_minimum_size.y = 26
    content.add_child(spacer)

    _add_button(content, "JOGAR", _on_play, true)
    _add_button(content, "CRIAR / EDITAR PERSONAGEM", _on_customize)
    _add_button(content, "CONFIGURAÇÕES", _on_settings)

    status_label = Label.new()
    status_label.text = "PROTÓTIPO • CONEXÃO ONLINE AINDA NÃO IMPLEMENTADA"
    status_label.add_theme_font_size_override("font_size", 12)
    status_label.add_theme_color_override("font_color", Color("#c3ccd8"))
    status_label.autowrap_mode = TextServer.AUTOWRAP_WORD_SMART
    content.add_child(status_label)

    var footer = Label.new()
    footer.text = "CIDADE 49 RP  |  VERSÃO DE DESENVOLVIMENTO"
    footer.anchor_left = 0.08
    footer.anchor_top = 0.94
    footer.anchor_right = 0.92
    footer.anchor_bottom = 0.99
    footer.add_theme_font_size_override("font_size", 12)
    footer.add_theme_color_override("font_color", Color("#aeb8c7"))
    add_child(footer)

    settings_popup = AcceptDialog.new()
    settings_popup.title = "Configurações"
    settings_popup.dialog_text = "Áudio: em desenvolvimento\\nQualidade gráfica: em desenvolvimento\\nControles: toque na tela (em desenvolvimento)"
    add_child(settings_popup)

    customize_popup = AcceptDialog.new()
    customize_popup.title = "Personalizar personagem"
    customize_popup.dialog_text = "A criação de personagem será o próximo módulo.\\nAqui você poderá escolher aparência, roupas e nome."
    add_child(customize_popup)

func _add_button(parent: VBoxContainer, caption: String, action: Callable, primary := false) -> void:
    var button = Button.new()
    button.text = caption
    button.custom_minimum_size = Vector2(330, 58)
    button.size_flags_horizontal = Control.SIZE_EXPAND_FILL
    button.add_theme_font_size_override("font_size", 18 if primary else 15)
    button.add_theme_color_override("font_color", Color("#101827") if primary else Color.WHITE)
    var normal = StyleBoxFlat.new()
    normal.bg_color = Color("#f2bd65") if primary else Color(0.08, 0.13, 0.20, 0.88)
    normal.border_width_left = 2
    normal.border_width_right = 2
    normal.border_width_top = 2
    normal.border_width_bottom = 2
    normal.border_color = Color("#f2bd65")
    normal.corner_radius_top_left = 8
    normal.corner_radius_top_right = 8
    normal.corner_radius_bottom_left = 8
    normal.corner_radius_bottom_right = 8
    button.add_theme_stylebox_override("normal", normal)
    var hover = normal.duplicate()
    hover.bg_color = Color("#ffd58c") if primary else Color("#263b50")
    button.add_theme_stylebox_override("hover", hover)
    button.pressed.connect(action)
    parent.add_child(button)

func _on_play() -> void:
    var config = ConfigFile.new()
    if config.load("user://cidade49.cfg") == OK and not str(config.get_value("personagem", "nome", "")).is_empty():
        get_tree().change_scene_to_file("res://scenes/World.tscn")
    else:
        get_tree().change_scene_to_file("res://scenes/CharacterCreator.tscn")

func _on_customize() -> void:
    get_tree().change_scene_to_file("res://scenes/CharacterCreator.tscn")

func _on_settings() -> void:
    settings_popup.popup_centered()
