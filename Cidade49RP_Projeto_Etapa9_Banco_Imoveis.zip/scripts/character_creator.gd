extends Control

var name_input: LineEdit
var preview: Control
var selected_color := Color("#3d8fbd")
var colors := [Color("#3d8fbd"), Color("#b85c45"), Color("#4b9b68"), Color("#9a72c4")]
var selected_index := 0
var message: Label

func _ready() -> void:
    _make_ui()

func _make_ui() -> void:
    var bg := ColorRect.new()
    bg.color = Color("#101827")
    bg.set_anchors_and_offsets_preset(Control.PRESET_FULL_RECT)
    add_child(bg)

    var root := VBoxContainer.new()
    root.set_anchors_preset(Control.PRESET_FULL_RECT)
    root.offset_left = 32
    root.offset_top = 24
    root.offset_right = -32
    root.offset_bottom = -24
    root.add_theme_constant_override("separation", 14)
    add_child(root)

    var title := Label.new()
    title.text = "CRIAÇÃO DE PERSONAGEM"
    title.horizontal_alignment = HORIZONTAL_ALIGNMENT_CENTER
    title.add_theme_font_size_override("font_size", 30)
    title.add_theme_color_override("font_color", Color("#f2bd65"))
    root.add_child(title)

    var info := Label.new()
    info.text = "Monte seu personagem para começar sua vida na Cidade 49."
    info.horizontal_alignment = HORIZONTAL_ALIGNMENT_CENTER
    info.add_theme_color_override("font_color", Color("#d4dce7"))
    root.add_child(info)

    var row := HBoxContainer.new()
    row.size_flags_vertical = Control.SIZE_EXPAND_FILL
    row.add_theme_constant_override("separation", 24)
    root.add_child(row)

    preview = Control.new()
    preview.custom_minimum_size = Vector2(240, 280)
    preview.size_flags_horizontal = Control.SIZE_EXPAND_FILL
    preview.size_flags_vertical = Control.SIZE_EXPAND_FILL
    preview.draw.connect(_draw_preview)
    row.add_child(preview)

    var form := VBoxContainer.new()
    form.size_flags_horizontal = Control.SIZE_EXPAND_FILL
    form.size_flags_vertical = Control.SIZE_SHRINK_CENTER
    form.add_theme_constant_override("separation", 12)
    row.add_child(form)

    var name_label := Label.new()
    name_label.text = "Nome do personagem"
    name_label.add_theme_color_override("font_color", Color.WHITE)
    form.add_child(name_label)

    name_input = LineEdit.new()
    name_input.placeholder_text = "Digite seu nome..."
    name_input.max_length = 18
    name_input.custom_minimum_size = Vector2(0, 48)
    form.add_child(name_input)

    var color_label := Label.new()
    color_label.text = "Cor da roupa"
    color_label.add_theme_color_override("font_color", Color.WHITE)
    form.add_child(color_label)

    var color_row := HBoxContainer.new()
    form.add_child(color_row)
    for i in range(colors.size()):
        var b := Button.new()
        b.custom_minimum_size = Vector2(48, 48)
        b.text = "●"
        b.add_theme_color_override("font_color", colors[i])
        b.add_theme_font_size_override("font_size", 28)
        b.pressed.connect(_select_color.bind(i))
        color_row.add_child(b)

    var hint := Label.new()
    hint.text = "A aparência 3D completa será adicionada em uma próxima etapa."
    hint.autowrap_mode = TextServer.AUTOWRAP_WORD_SMART
    hint.add_theme_color_override("font_color", Color("#aeb8c7"))
    form.add_child(hint)

    message = Label.new()
    message.horizontal_alignment = HORIZONTAL_ALIGNMENT_CENTER
    message.add_theme_color_override("font_color", Color("#ffc96b"))
    root.add_child(message)

    var buttons := HBoxContainer.new()
    buttons.alignment = BoxContainer.ALIGNMENT_CENTER
    buttons.add_theme_constant_override("separation", 16)
    root.add_child(buttons)
    _make_button(buttons, "VOLTAR", _back, false)
    _make_button(buttons, "SALVAR E ENTRAR", _save_and_enter, true)

    var cfg := ConfigFile.new()
    if cfg.load("user://cidade49.cfg") == OK:
        name_input.text = str(cfg.get_value("personagem", "nome", ""))
        selected_index = int(cfg.get_value("personagem", "cor", 0)) % colors.size()
        selected_color = colors[selected_index]
    preview.queue_redraw()

func _make_button(parent: HBoxContainer, caption: String, action: Callable, primary: bool) -> void:
    var b := Button.new()
    b.text = caption
    b.custom_minimum_size = Vector2(210, 54)
    b.add_theme_font_size_override("font_size", 16)
    var style := StyleBoxFlat.new()
    style.bg_color = Color("#f2bd65") if primary else Color("#263b50")
    style.corner_radius_top_left = 8
    style.corner_radius_top_right = 8
    style.corner_radius_bottom_left = 8
    style.corner_radius_bottom_right = 8
    b.add_theme_stylebox_override("normal", style)
    b.pressed.connect(action)
    parent.add_child(b)

func _select_color(index: int) -> void:
    selected_index = index
    selected_color = colors[index]
    preview.queue_redraw()

func _draw_preview() -> void:
    if preview.size.x <= 0:
        return
    var center := Vector2(preview.size.x * 0.5, preview.size.y * 0.5)
    preview.draw_circle(center + Vector2(0, 88), 76, Color("#1a2938"))
    preview.draw_circle(center + Vector2(0, -42), 34, Color("#bd8c69"))
    preview.draw_rect(Rect2(center + Vector2(-43, -5), Vector2(86, 105)), selected_color, true)
    preview.draw_rect(Rect2(center + Vector2(-43, 84), Vector2(34, 70)), Color("#202b3a"), true)
    preview.draw_rect(Rect2(center + Vector2(9, 84), Vector2(34, 70)), Color("#202b3a"), true)
    preview.draw_line(center + Vector2(-13, -45), center + Vector2(13, -45), Color("#382a25"), 4)
    preview.draw_string(ThemeDB.fallback_font, Vector2(10, preview.size.y - 8), "PRÉVIA DO PERSONAGEM", HORIZONTAL_ALIGNMENT_CENTER, preview.size.x - 20, 13, Color("#cbd5e1"))

func _save_and_enter() -> void:
    var player_name := name_input.text.strip_edges()
    if player_name.length() < 3:
        message.text = "Digite um nome com pelo menos 3 caracteres."
        return
    var cfg := ConfigFile.new()
    cfg.set_value("personagem", "nome", player_name)
    cfg.set_value("personagem", "cor", selected_index)
    var err := cfg.save("user://cidade49.cfg")
    if err != OK:
        message.text = "Não foi possível salvar o personagem."
        return
    get_tree().change_scene_to_file("res://scenes/World.tscn")

func _back() -> void:
    get_tree().change_scene_to_file("res://scenes/MainMenu.tscn")
